<h1 align="center">
  <img src="icon.png" width="1024" height="1024" />
  MCBE Custom Skin Pack Template
</h1>
Authors: YHSora0205 & Mojang Studios & mcxiaolan CN

[简体中文](README_CHS.md) | [English](README.md)

Modify and Use
--

The modified copy CANNOT modify **author-related information**.  
When modifying this pack, you need to change the uuid in the **manifest.json**.  
You can use this pack in your **minecraft client** (not in a resource pack).  
Modified copies must be **freely** available to all people.  
Free for **non-commercial** use only.

Original Video Link
--

<https://b23.tv/VKhHXyj>  
Uploader BilibiliUID:355877984  
(Name: LanTianYa)

WARNING&ATTENTIONs
--

Only support files within these limits:  
Skin size **64x64** or **64x32**,  
Cape size **64x32**,  
and all the media files must be in **.png** format.  
If using files that do not comply with the above limits,  
you should be **responsible** for ANY consequences.  

Don't use full-width symbols in manifest.json & skins.json,it will make the pack don't  work.  
Please use English Input Method while editing JSON files.  

(If you faced the problems hinted, do not ask Admins, these are already mentioned in this file)  

(If your game can't load the characters, change your NET Environment or use a Proxy to boot client.)  
(Still not work? check your JSON Format, and check if the file name is synced both in JSON & path.)  
(We can't fix the problems caused by NET Environment, just retry more and more times.)

Contacts
--

Visit [**`LTY's Group MC site`**](https://mc.ltya.top/cape-or-json/) for **more** **Information**.  
You can also join our QQ Group: **735517229**

Site Recommends
--

- For more capes:
  - `Global`
    - [SkinMC Capes](https://skinmc.net/capes)
  - `China`
    - [LittleSkin Cape](https://littleskin.cn/skinlib?filter=cape&sort=likes&page=1)

- For more skins:
  - `Global`
    - [SkinMC](https://skinmc.net)
    - [NameMC](https://namemc.com)
  - `China`
    - [LittleSkin](https://littleskin.cn/skinlib/)
- [JSON Format](https://www.json.org)
- [Minecraft Wiki](https://minecraft.wiki)
